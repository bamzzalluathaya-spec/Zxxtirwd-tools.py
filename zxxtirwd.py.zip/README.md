# ZXxTiRWD Tools
Tools keamanan berbasis bot Telegram buatan zxxtirwd😈  
Cara pakai:
1. pkg install git python -y
2. git clone https://github.com/zallu/zxxtirwdtools
3. cd zxxtirwdtools
4. python bot.py